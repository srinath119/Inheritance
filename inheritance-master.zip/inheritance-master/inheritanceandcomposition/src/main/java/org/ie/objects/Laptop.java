package org.ie.objects;

import java.util.List;

public class Laptop extends Computer {
     private List proccessor;
     private List Ram;
     private String Os;
     private String typeOfScreen;
}
