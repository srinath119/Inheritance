package org.ie.objects;

public class Cpu {
   private String name;
   private String ramType;
   private String processor;
}
