package org.ie.objects;

public class Desktop extends Computer {
    private Cpu cpu;
    
}
