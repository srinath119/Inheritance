package org.ie.objects;

public class Computer {
    private String companyName;
    
}
